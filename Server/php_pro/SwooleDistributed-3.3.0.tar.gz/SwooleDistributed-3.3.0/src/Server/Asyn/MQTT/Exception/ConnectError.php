<?php

/**
 * MQTT Client
 */



namespace Server\Asyn\MQTT\Exception;
use Server\Asyn\MQTT\Exception;

/**
 * Exception: Connect failed with return value
 *
 *
 *
 */
class ConnectError extends Exception {}


# EOF