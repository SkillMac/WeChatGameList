<?php

/**
 * MQTT Client
 */

namespace Server\Asyn\MQTT;

/**
 * Exception class
 */
class Exception extends \Exception
{

}


# EOF