<?php

/**
 * MQTT Client
 */

namespace Server\Asyn\MQTT\Exception;
use Server\Asyn\MQTT\Exception;

/**
 * Exception \0
 *
 * Should be useless becauses mosquitto does not cares \0
 *
 */
class UTF8Null extends Exception {}


# EOF