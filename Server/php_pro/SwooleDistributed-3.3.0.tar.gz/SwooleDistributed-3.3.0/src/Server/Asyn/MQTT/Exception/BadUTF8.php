<?php

/**
 * MQTT Client
 */

namespace Server\Asyn\MQTT\Exception;
use Server\Asyn\MQTT\Exception;

/**
 * Exception: ill-formed UTF-8
 */
class BadUTF8 extends Exception {}


# EOF