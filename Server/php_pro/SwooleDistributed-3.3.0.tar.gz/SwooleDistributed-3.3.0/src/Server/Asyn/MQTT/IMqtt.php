<?php
/**
 * Created by PhpStorm.
 * User: zhangjincheng
 * Date: 17-8-31
 * Time: 下午3:28
 */

namespace Server\Asyn\MQTT;


interface IMqtt
{
    public function version();
}