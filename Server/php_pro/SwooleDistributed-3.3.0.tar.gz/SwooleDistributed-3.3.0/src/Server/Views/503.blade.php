@extends('server::layout')

@section('title', 'Service Unavailable')

@section('message', 'Be right back.')
