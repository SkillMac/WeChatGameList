<?php
/**
 * Created by PhpStorm.
 * User: zhangjincheng
 * Date: 18-3-21
 * Time: 下午5:10
 */

namespace Server\Controllers;


use Server\CoreBase\Controller;

class AppController extends Controller
{
    public function onConnect()
    {

    }
    public function onClose()
    {

    }
}