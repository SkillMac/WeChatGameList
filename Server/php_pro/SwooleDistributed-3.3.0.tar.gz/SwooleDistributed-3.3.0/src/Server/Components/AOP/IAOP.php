<?php
/**
 * Created by PhpStorm.
 * User: zhangjincheng
 * Date: 17-10-12
 * Time: 下午7:28
 */

namespace Server\Components\AOP;


interface IAOP
{
    function getProxy();
}