<?php
/**
 * Created by PhpStorm.
 * User: zhangjincheng
 * Date: 17-2-27
 * Time: 下午4:07
 */
$config['config_version'] = 3;
return $config;